﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MySql.Data.MySqlClient;
using System.Windows.Controls;

namespace DWH
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<DBConnection> db2 = new List<DBConnection>();
        public MainWindow()
        {
            InitializeComponent();
            

           
            user_list.ItemsSource = db2;
        }

        private void Name_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            String query = "";
            String type = "";
            String number = "";
            String org = "";

            query = Textbox.Text;

            type = textbox1.Text;
            DBConnection db1 = new DBConnection();

            try
            {
                DBConnection db = new DBConnection();
                MySqlConnection dbcon = db.get_Connection();

                if (type != "Select")
                {
                    db.add_user(query, dbcon);
                }
                else
                {
                    db2=db.select_user(query, dbcon);
                    // textBox2.Text = db1.name1;
                 

                    db2.Add(new DBConnection() { name1 = db2[0].name1, cnic1 = db2[0].cnic1, number1 = db2[0].number1, org1 = db2[0].org1 });
                   
                    user_list.ItemsSource = db2;
                }

            }
            catch(Exception)
            {
                Console.WriteLine("Database Connection not established");
            }
        }



    }
}
